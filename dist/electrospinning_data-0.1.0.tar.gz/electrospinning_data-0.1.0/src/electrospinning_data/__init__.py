from typing import Optional, Union, Dict, Any
import pandas as pd

from .client import ElectrospinningClient
from .exceptions import (
    ElectrospinningError, 
    APIError, 
    ValidationError, 
    TransportError, 
    ParsingError
)
from .filters import FilterBuilder
from .models import ExperimentRecord, VersionInfo
from .mappers import DataFrameMapper

__version__ = "0.1.0"
__all__ = [
    "ElectrospinningClient", 
    "FilterBuilder",
    "ExperimentRecord",
    "VersionInfo",
    "DataFrameMapper",
    "ElectrospinningError", 
    "APIError", 
    "ValidationError", 
    "TransportError",
    "ParsingError",
    "load_latest_dataset",
    "load_versioned_dataset"
]

def load_latest_dataset(
    filters: Optional[Union[Dict[str, Any], FilterBuilder]] = None
) -> pd.DataFrame:
    """
    Convenience function to load the latest dataset as a pandas DataFrame.
    """
    client = ElectrospinningClient()
    try:
        return client.download_latest(filters=filters)
    finally:
        client.close()

def load_versioned_dataset(
    version: str, 
    filters: Optional[Union[Dict[str, Any], FilterBuilder]] = None
) -> pd.DataFrame:
    """
    Convenience function to load a specific dataset version as a pandas DataFrame.
    """
    client = ElectrospinningClient()
    try:
        return client.download_version(version, filters=filters)
    finally:
        client.close()
