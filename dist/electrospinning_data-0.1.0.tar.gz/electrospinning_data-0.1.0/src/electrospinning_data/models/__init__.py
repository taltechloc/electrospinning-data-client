from dataclasses import dataclass, field
from typing import Optional, Dict, Any, List
from ..exceptions import ValidationError


def _to_float(value: Any) -> Optional[float]:
    """Safely convert value to float, ignoring invalid types."""
    if value is None:
        return None
    try:
        return float(value)
    except (ValueError, TypeError):
        return None


@dataclass
class ResearchMetadata:
    doi: Optional[str] = None
    publication_title: Optional[str] = None
    custom_device: Optional[bool] = None
    device_manufacturer: Optional[str] = None
    device_model: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ResearchMetadata":
        return cls(
            doi=data.get("doi"),
            publication_title=data.get("publicationTitle"),
            custom_device=data.get("customDevice"),
            device_manufacturer=data.get("deviceManufacturer"),
            device_model=data.get("deviceModel")
        )


@dataclass
class PolymerComponent:
    name: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "PolymerComponent":
        name = data.get("polymerName") or data.get("name")
        if not name:
            raise ValidationError("Polymer name is required")
        return cls(name=name)


@dataclass
class SolventComponent:
    name: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SolventComponent":
        name = data.get("solventName") or data.get("name")
        if not name:
            raise ValidationError("Solvent name is required")
        return cls(name=name)


@dataclass
class SolutionProperty:
    concentration: Optional[float] = None
    concentration_unit: Optional[str] = None
    viscosity: Optional[float] = None
    viscosity_unit: Optional[str] = None
    surface_tension: Optional[float] = None
    surface_tension_unit: Optional[str] = None
    conductivity: Optional[float] = None
    conductivity_unit: Optional[str] = None
    evaporation_rate: Optional[float] = None
    evaporation_rate_unit: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "SolutionProperty":
        return cls(
            concentration=_to_float(data.get("concentration")),
            concentration_unit=data.get("concentrationUnit"),
            viscosity=_to_float(data.get("viscosity") or data.get("solutionViscosity")),
            viscosity_unit=data.get("viscosityUnit"),
            surface_tension=_to_float(data.get("surfaceTension")),
            surface_tension_unit=data.get("surfaceTensionUnit"),
            conductivity=_to_float(data.get("conductivity") or data.get("solutionConductivity")),
            conductivity_unit=data.get("conductivityUnit"),
            evaporation_rate=_to_float(data.get("evaporationRate")),
            evaporation_rate_unit=data.get("evaporationRateUnit")
        )


@dataclass
class NeedleProperty:
    needle_type: Optional[str] = None
    needle_definition: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "NeedleProperty":
        return cls(
            needle_type=data.get("needleType"),
            needle_definition=data.get("needleDefinition")
        )


@dataclass
class CollectorProperty:
    collector_type: Optional[str] = None
    collector_definition: Optional[Dict[str, Any]] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "CollectorProperty":
        return cls(
            collector_type=data.get("collectorType"),
            collector_definition=data.get("collectorDefinition")
        )


@dataclass
class ProcessParameter:
    voltage: Optional[float] = None
    voltage_unit: Optional[str] = None
    flow_rate: Optional[float] = None
    flow_rate_unit: Optional[str] = None
    tip_collector_distance: Optional[float] = None
    tip_collector_distance_unit: Optional[str] = None
    spinning_duration: Optional[float] = None
    spinning_duration_unit: Optional[str] = None
    instability: List[Dict[str, Any]] = field(default_factory=list)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ProcessParameter":
        return cls(
            voltage=_to_float(data.get("voltage")),
            voltage_unit=data.get("voltageUnit"),
            flow_rate=_to_float(data.get("flowRate")),
            flow_rate_unit=data.get("flowRateUnit"),
            tip_collector_distance=_to_float(data.get("tipCollectorDistance")),
            tip_collector_distance_unit=data.get("tipCollectorDistanceUnit"),
            spinning_duration=_to_float(data.get("spinningDuration")),
            spinning_duration_unit=data.get("spinningDurationUnit"),
            instability=data.get("instability") or []
        )


@dataclass
class AmbientParameter:
    temperature: Optional[float] = None
    temperature_unit: Optional[str] = None
    humidity: Optional[float] = None
    humidity_unit: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "AmbientParameter":
        return cls(
            temperature=_to_float(data.get("temperature")),
            temperature_unit=data.get("temperatureUnit"),
            humidity=_to_float(data.get("humidity")),
            humidity_unit=data.get("humidityUnit")
        )


@dataclass
class FiberProperty:
    is_formation_stable: Optional[str] = None
    fiber_morphology: List[Dict[str, Any]] = field(default_factory=list)
    fiber_diameter: Optional[float] = None
    fiber_diameter_unit: Optional[str] = None
    fiber_diameter_variation: Optional[float] = None
    fiber_diameter_variation_unit: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FiberProperty":
        return cls(
            is_formation_stable=data.get("isFormationStable"),
            fiber_morphology=data.get("fiberMorphology") or [],
            fiber_diameter=_to_float(data.get("fiberDiameter")),
            fiber_diameter_unit=data.get("fiberDiameterUnit"),
            fiber_diameter_variation=_to_float(data.get("fiberDiameterVariation")),
            fiber_diameter_variation_unit=data.get("fiberDiameterVariationUnit")
        )


@dataclass
class MechanicalProperty:
    tensile_strength: Optional[float] = None
    tensile_strength_unit: Optional[str] = None
    modulus: Optional[float] = None
    modulus_unit: Optional[str] = None
    elongation_at_break: Optional[float] = None
    elongation_at_break_unit: Optional[str] = None
    fracture_behaviour: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "MechanicalProperty":
        return cls(
            tensile_strength=_to_float(data.get("tensile_strength")),
            tensile_strength_unit=data.get("tensile_strength_unit"),
            modulus=_to_float(data.get("modulus")),
            modulus_unit=data.get("modulus_unit"),
            elongation_at_break=_to_float(data.get("elongation_at_break")),
            elongation_at_break_unit=data.get("elongation_at_break_unit"),
            fracture_behaviour=data.get("fracture_behaviour")
        )


@dataclass
class FunctionalProperty:
    surface_area: Optional[float] = None
    surface_area_unit: Optional[str] = None
    porosity: Optional[float] = None
    porosity_unit: Optional[str] = None
    permeability: Optional[float] = None
    permeability_unit: Optional[str] = None

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "FunctionalProperty":
        return cls(
            surface_area=_to_float(data.get("surface_area")),
            surface_area_unit=data.get("surface_area_unit"),
            porosity=_to_float(data.get("porosity")),
            porosity_unit=data.get("porosity_unit"),
            permeability=_to_float(data.get("permeability")),
            permeability_unit=data.get("permeability_unit")
        )


@dataclass
class ExperimentRecord:
    """Represents a single experiment record in the dataset."""
    record_id: int
    research_metadata: ResearchMetadata = field(default_factory=ResearchMetadata)
    polymer_components: List[PolymerComponent] = field(default_factory=list)
    solvent_components: List[SolventComponent] = field(default_factory=list)
    solution_property: SolutionProperty = field(default_factory=SolutionProperty)
    needle_property: NeedleProperty = field(default_factory=NeedleProperty)
    collector_property: CollectorProperty = field(default_factory=CollectorProperty)
    process_parameter: ProcessParameter = field(default_factory=ProcessParameter)
    ambient_parameter: AmbientParameter = field(default_factory=AmbientParameter)
    fiber_property: FiberProperty = field(default_factory=FiberProperty)
    mechanical_property: MechanicalProperty = field(default_factory=MechanicalProperty)
    functional_property: FunctionalProperty = field(default_factory=FunctionalProperty)
    
    # Raw data for backward compatibility or debugging
    raw_data: Dict[str, Any] = field(default_factory=dict, repr=False)

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "ExperimentRecord":
        """
        Create a record from a dictionary, mapping API camelCase to snake_case.
        Includes defensive validation for required identifiers.
        """
        record_id = data.get("recordId") or data.get("experimentId")
        if record_id is None:
            raise ValidationError("Missing required field: recordId")

        poly_prop = data.get("polymerProperty", {}) or {}
        poly_components = [
            PolymerComponent.from_dict(p)
            for p in poly_prop.get("polymerComponents", [])
            if p is not None
        ]
        
        solv_prop = data.get("solventProperty", {}) or {}
        solv_components = [
            SolventComponent.from_dict(s)
            for s in solv_prop.get("solventComponents", [])
            if s is not None
        ]

        return cls(
            record_id=int(record_id),
            research_metadata=ResearchMetadata.from_dict(data.get("researchMetadata", {}) or {}),
            polymer_components=poly_components,
            solvent_components=solv_components,
            solution_property=SolutionProperty.from_dict(data.get("solutionProperty", {}) or {}),
            needle_property=NeedleProperty.from_dict(data.get("needleProperty", {}) or {}),
            collector_property=CollectorProperty.from_dict(data.get("collectorProperty", {}) or {}),
            process_parameter=ProcessParameter.from_dict(data.get("processParameter", {}) or {}),
            ambient_parameter=AmbientParameter.from_dict(data.get("ambientParameter", {}) or {}),
            fiber_property=FiberProperty.from_dict(data.get("fiberProperty", {}) or {}),
            mechanical_property=MechanicalProperty.from_dict(data.get("mechanicalProperty", {}) or {}),
            functional_property=FunctionalProperty.from_dict(data.get("functionalProperty", {}) or {}),
            raw_data=data
        )


@dataclass
class VersionInfo:
    """Represents metadata for a dataset version snapshot."""
    version_identifier: str
    record_count: int
    created_at: str

    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> "VersionInfo":
        version_id = data.get("versionIdentifier")
        if not version_id:
             raise ValidationError("Version identifier is missing")
             
        return cls(
            version_identifier=str(version_id),
            record_count=int(data.get("recordCount", 0)),
            created_at=str(data.get("createdAt", ""))
        )
