"""
Example showing how to apply filters when downloading data.
"""
import electrospinning_data as ed

def main():
    # Define filters
    # Here we look for PAN nanofibers produced at 25kV
    filters = {
        "polymer": "PAN",
        "morphology": "Nanofiber",
        "voltageMin": 24,
        "voltageMax": 26
    }
    
    print(f"Fetching data with filters: {filters}")
    
    df = ed.load_latest_dataset(filters=filters)
    
    if df.empty:
        print("No matching records found.")
    else:
        print(f"Found {len(df)} matching records.")
        print(df[['recordId', 'polymer', 'voltage', 'fiberDiameter']].head())

if __name__ == "__main__":
    main()
